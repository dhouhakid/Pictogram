-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 23 déc. 2022 à 21:30
-- Version du serveur : 10.4.22-MariaDB
-- Version de PHP : 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `pictogram`
--

-- --------------------------------------------------------

--
-- Structure de la table `block_list`
--

CREATE TABLE `block_list` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `blocked_user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `block_list`
--

INSERT INTO `block_list` (`id`, `user_id`, `blocked_user_id`) VALUES
(13, 1, 16);

-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `user_id`, `comment`, `created_at`) VALUES
(49, 14, 1, 'bien', '2022-12-23 20:07:24'),
(50, 15, 1, 'bon courage <3', '2022-12-23 20:23:41'),
(51, 16, 2, 'hahaha', '2022-12-23 20:24:47');

-- --------------------------------------------------------

--
-- Structure de la table `follow_list`
--

CREATE TABLE `follow_list` (
  `id` int(11) NOT NULL,
  `follower_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `follow_list`
--

INSERT INTO `follow_list` (`id`, `follower_id`, `user_id`) VALUES
(86, 14, 15),
(88, 16, 2),
(89, 2, 1),
(90, 2, 16),
(91, 2, 2),
(92, 1, 2),
(93, 17, 1),
(94, 17, 2),
(95, 17, 16),
(96, 16, 17),
(97, 1, 17),
(98, 2, 17);

-- --------------------------------------------------------

--
-- Structure de la table `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `likes`
--

INSERT INTO `likes` (`id`, `post_id`, `user_id`) VALUES
(95, 14, 2),
(96, 14, 1),
(97, 14, 16),
(98, 14, 17),
(99, 16, 2),
(100, 16, 17),
(101, 15, 17);

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `msg` text NOT NULL,
  `read_status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `messages`
--

INSERT INTO `messages` (`id`, `from_user_id`, `to_user_id`, `msg`, `read_status`, `created_at`) VALUES
(42, 16, 1, 'bonjour', 1, '2022-12-23 19:55:41'),
(43, 1, 17, 'have a nice trip', 1, '2022-12-23 20:24:03'),
(44, 17, 1, 'thank you l3a9ba lik', 0, '2022-12-23 20:26:15');

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `from_user_id` int(11) NOT NULL,
  `read_status` int(11) NOT NULL DEFAULT 0,
  `post_id` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `notifications`
--

INSERT INTO `notifications` (`id`, `to_user_id`, `message`, `created_at`, `from_user_id`, `read_status`, `post_id`) VALUES
(112, 1, 'started following you !', '2022-12-23 19:55:23', 16, 1, '0'),
(113, 2, 'started following you !', '2022-12-23 19:55:24', 16, 1, '0'),
(114, 16, 'blocked you', '2022-12-23 19:56:17', 1, 1, '0'),
(115, 1, 'started following you !', '2022-12-23 19:56:41', 2, 1, '0'),
(116, 16, 'started following you !', '2022-12-23 19:56:42', 2, 1, '0'),
(117, 2, 'started following you !', '2022-12-23 19:58:51', 2, 1, '0'),
(118, 2, 'started following you !', '2022-12-23 20:07:09', 1, 1, '0'),
(119, 2, 'commented on your post', '2022-12-23 20:07:24', 1, 1, '14'),
(120, 2, 'liked your post !', '2022-12-23 20:07:32', 1, 1, '14'),
(121, 2, 'liked your post !', '2022-12-23 20:07:56', 16, 1, '14'),
(122, 1, 'started following you !', '2022-12-23 20:18:21', 17, 1, '0'),
(123, 2, 'started following you !', '2022-12-23 20:18:23', 17, 1, '0'),
(124, 16, 'started following you !', '2022-12-23 20:18:24', 17, 1, '0'),
(125, 2, 'liked your post !', '2022-12-23 20:19:18', 17, 1, '14'),
(126, 17, 'started following you !', '2022-12-23 20:21:01', 16, 1, '0'),
(127, 17, 'started following you !', '2022-12-23 20:23:09', 1, 1, '0'),
(128, 17, 'commented on your post', '2022-12-23 20:23:41', 1, 1, '15'),
(129, 17, 'started following you !', '2022-12-23 20:24:34', 2, 1, '0'),
(130, 16, 'liked your post !', '2022-12-23 20:24:36', 2, 0, '16'),
(131, 16, 'commented on your post', '2022-12-23 20:24:47', 2, 0, '16'),
(132, 16, 'liked your post !', '2022-12-23 20:26:24', 17, 0, '16');

-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_img` text NOT NULL,
  `post_text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `post_img`, `post_text`, `created_at`) VALUES
(14, 2, '1671825470aha.jpg', 'art', '2022-12-23 19:57:50'),
(15, 17, '1671826834_Les voyages forment la jeunesse_ de Montaigne.jpg', 'bye bye hehe', '2022-12-23 20:20:34'),
(16, 16, '1671826919272725132_460972755620675_6548441426672000693_n.jpg', 'hehe', '2022-12-23 20:21:59');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `profile_pic` text NOT NULL DEFAULT 'default_profile.jpg',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ac_status` int(11) NOT NULL COMMENT '0=not verified,1=active,2=blocked'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `gender`, `email`, `username`, `password`, `profile_pic`, `created_at`, `updated_at`, `ac_status`) VALUES
(1, 'dhouha', 'kid', 2, 'dhouhakid@gmail.com', 'dhouha', 'e10adc3949ba59abbe56e057f20f883e', 'hello.png', '2022-12-23 18:10:13', '2022-12-23 20:15:30', 1),
(2, 'deedee', 'deedee', 2, 'chanhate63@gmail.com', 'deedee', 'e10adc3949ba59abbe56e057f20f883e', 'melody.jpg', '2022-12-23 18:22:50', '2022-12-23 20:15:30', 1),
(16, 'Dsi', 'info', 1, 'dhouhadsi23@gmail.com', 'Dsi23', 'e10adc3949ba59abbe56e057f20f883e', 'default_profile.jpg', '2022-12-23 19:54:54', '2022-12-23 19:55:08', 1),
(17, 'kuromi', 'kitty', 2, 'kuromi@gmail.com', 'kuromi', 'e10adc3949ba59abbe56e057f20f883e', '1671826751kuromi.jpg', '2022-12-23 20:16:47', '2022-12-23 20:19:11', 1);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `block_list`
--
ALTER TABLE `block_list`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `follow_list`
--
ALTER TABLE `follow_list`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `block_list`
--
ALTER TABLE `block_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT pour la table `follow_list`
--
ALTER TABLE `follow_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT pour la table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT pour la table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT pour la table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;

--
-- AUTO_INCREMENT pour la table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
